----------------------------------------------------------------------------------------
--
-- File name:   sql_profile_distinct_hints.sql
--
-- Purpose:     Show counts of hint types associated with a group of SQL Profiles.
-
-- Author:      Kerry Osborne
--
-- Usage:       This scripts prompts for one value.
--
--              profile_name: may be wildcarded 
--
-- Description: This script pulls the hints associated with a group of SQL Profiles 
--
-- Mods:        Modified to check for 10g or 11g as the hint structure changed.
--
--              See kerryosborne.oracle-guy.com for additional information.
---------------------------------------------------------------------------------------
--
set sqlblanklines on
set feedback off
accept profile_name -
       prompt 'Enter value for profile_name: ' -
       default 'X0X0X0X0'

declare
ar_profile_hints sys.sqlprof_attr;
cl_sql_text clob;
version varchar2(3);
l_category varchar2(30);
l_force_matching varchar2(3);
b_force_matching boolean;
   TYPE number_array
   IS TABLE OF number
      INDEX BY PLS_INTEGER;
   count_hints number_array;

begin
 select regexp_replace(version,'\..*') into version from v$instance;

if version = '10' then

-- dbms_output.put_line('version: '||version);
   execute immediate -- to avoid 942 error
   'select hint, count(*) from ( '||
   'select regexp_replace(attr_val,''\(.*$'') hint '|| -- eliminate ( to end of line
   'from dba_sql_profiles p, sqlprof$attr h '||
   'where p.signature = h.signature '||
   'and name like (''&&profile_name'')) '||
   'group by hint '||
   'order by hint'
   bulk collect
   into ar_profile_hints, count_hints;

elsif version = '11' then

-- dbms_output.put_line('version: '||version);
   execute immediate -- to avoid 942 error
   'select hint, count(*) from ('||
   'select regexp_replace(hint,''\(.*$'') hint '||  -- eliminate ( to end of line
   'from (select p.name, p.signature, p.category, row_number() '||
   '      over (partition by sd.signature, sd.category order by sd.signature) row_num, '||
   '      extractValue(value(t), ''/hint'') hint '||
   'from sqlobj$data sd, dba_sql_profiles p, '||
   '     table(xmlsequence(extract(xmltype(sd.comp_data), '||
   '                               ''/outline_data/hint''))) t '||
   'where sd.obj_type = 1 '||
   'and p.signature = sd.signature '||
   'and p.category = sd.category '||
   'and p.name like decode(''&&profile_name'',''X0X0X0X0'',p.name,''&&profile_name''))) '||
   'group by hint '||
   'order by hint'
   bulk collect
   into ar_profile_hints, count_hints;

end if;

  dbms_output.put_line(' ');
  dbms_output.put_line('HINT                                               COUNT');
  dbms_output.put_line('-------------------------------------------------- ----------');
  for i in 1..ar_profile_hints.count loop
    dbms_output.put_line(rpad(ar_profile_hints(i),50)||' '||lpad(count_hints(i),10));
  end loop;
  dbms_output.put_line(' ');
  dbms_output.put_line(ar_profile_hints.count||' rows selected.');
  dbms_output.put_line(' ');

end;
/
undef profile_name
set feedback on

