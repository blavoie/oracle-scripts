-- List AWR snapshots for specified number of days by instance
--

col start_time for a30
col end_time for a30

accept p_inst number default 1 prompt 'Instance Number (default 1)     : '
accept p_days number default 7 prompt 'Report Interval (default 7 days): '

	select snap_id,  
		   case when (startup_time = prev_startup_time) or rownum = 1 then '' 
			   else 'Database bounce' end as bounce,
		   start_time, replace(end_time-start_time,'+000000000 ','') duration, snap_level
	from (
	select snap_id, s.instance_number, begin_interval_time start_time, 
		   end_interval_time end_time, snap_level, flush_elapsed,
		   lag(s.startup_time) over (partition by s.dbid, s.instance_number 
		   					   order by s.snap_id) prev_startup_time,
		   s.startup_time
	from  dba_hist_snapshot s, v$instance i
	where begin_interval_time between sysdate-&p_days and sysdate 
	and   s.instance_number = i.instance_number
	and   s.instance_number = &p_inst
	order by snap_id
	)
	order by snap_id, start_time ;


clear columns
clear breaks
undef p_inst
undef p_days

