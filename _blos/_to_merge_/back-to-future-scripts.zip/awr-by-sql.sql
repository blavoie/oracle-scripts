-- Returns SQL statements from AWR for a specified SQL_ID
--

SELECT  sql_id, plan_hash_value, 
		sum(executions_delta) num_execs,
		sum(rows_processed_delta) num_rows,
		trunc(sum(cpu_time_delta)/1000000/60) cpu_minutes,
		trunc(sum(elapsed_time_delta)/1000000/60) elapsed_minutes
FROM    dba_hist_sqlstat
WHERE   sql_id = '&sqlid'
GROUP BY sql_id, plan_hash_value
ORDER BY sql_id, cpu_minutes ;

