-- Returns SQL statements from AWR that have the same PLAN_HASH_VALUE
--

SELECT  sql_id, plan_hash_value, 
		sum(executions_delta) num_execs,
		sum(rows_processed_delta) num_rows,
		trunc(sum(cpu_time_delta)/1000000/60) cpu_minutes,
		trunc(sum(elapsed_time_delta)/1000000/60) elapsed_minutes
FROM    dba_hist_sqlstat
WHERE   plan_hash_value = &phv
GROUP BY plan_hash_value, sql_id
ORDER BY cpu_minutes desc, plan_hash_value;


