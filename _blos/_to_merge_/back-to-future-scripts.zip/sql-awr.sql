-- Select data from AWR for a specified SQL_ID
--

set long 32000 numwidth 15
set lines 4000
set pages 1000

col sql_text format a150 heading 'SQL Statement'

select sql_text from DBA_HIST_SQLTEXT where sql_id = '&&sql_id';

column snap_id head 'Snap#' format 9999999
column instance_number head 'Inst#' format 99999

column sorts_total  head 'Sorts' format 99999
column executions_total  head 'Execs' format 99999
column disk_reads_total  head 'PIO'
column buffer_gets_total  head 'LIO'
column rows_processed_total  head 'Rows'
column cpu_time_total  head 'CPU'
column elapsed_time_total  head 'Elapsed'
column iowait_total  head 'IO Wait'
column clwait_total  head 'Cluster Wait'

column sorts_delta  head 'Sorts' format 99999
column executions_delta  head 'Execs' format 99999
column disk_reads_delta  head 'PIO' 
column buffer_gets_delta  head 'LIO' 
column rows_processed_delta  head 'Rows' 
column cpu_time_delta  head 'CPU' 
column elapsed_time_delta  head 'Elapsed' 
column iowait_delta  head 'IO Wait' 
column clwait_delta  head 'Cluster Wait' 

column snap_tm head 'Snap Time'
column plan_hash_value head 'Plan HV' format 999999999999


select a.snap_id, to_char(b.begin_interval_time,'mm/dd/yyyy hh24:mi') snap_tm, a.instance_number, a.plan_hash_value, a.sorts_delta, 
a.executions_delta, a.disk_reads_delta, a.buffer_gets_delta, a.rows_processed_delta,
a.cpu_time_delta/1000000 cpu_time_delta, a.elapsed_time_delta/1000000 elapsed_time_delta, a.iowait_delta/1000000 iowait_delta, 
a.clwait_delta/1000000 clwait_delta 
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.sql_id = '&sql_id'
and a.snap_id = b.snap_id
and a.instance_number = b.instance_number
and a.dbid = b.dbid
order by a.instance_number, a.snap_id desc, a.plan_hash_value ;


undef sql_id

clear columns

