-- Retrieve execution plan for specified SQL from AWR
--

set long 32000 numwidth 15
set lines 4000
set pages 1000


SELECT * FROM table(DBMS_XPLAN.DISPLAY_AWR('&sql_id',&phv,null,nvl('&fmt','TYPICAL'));


undef sql_id
undef phv
undef fmt
