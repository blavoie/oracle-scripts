prompt alter session set statistics_level = &1;;
alter session set statistics_level = &1;

