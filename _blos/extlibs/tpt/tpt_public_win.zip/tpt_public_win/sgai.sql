select * from v$sgainfo;
