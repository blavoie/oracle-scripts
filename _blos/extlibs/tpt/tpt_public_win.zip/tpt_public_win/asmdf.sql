SELECT * FROM v$asm_diskgroup;

