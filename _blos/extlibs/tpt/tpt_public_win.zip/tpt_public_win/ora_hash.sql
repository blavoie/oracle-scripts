select to_char(ora_hash('&1'), 'XXXXXXXX') from dual;
