@@saveset

set lines 80
describe &1

@@loadset

