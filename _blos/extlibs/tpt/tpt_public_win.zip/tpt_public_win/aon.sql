set autotrace trace stat

