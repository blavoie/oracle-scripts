select * from &1
/
