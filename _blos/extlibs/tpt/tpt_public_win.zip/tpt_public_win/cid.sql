exec dbms_session.set_identifier('&1')
