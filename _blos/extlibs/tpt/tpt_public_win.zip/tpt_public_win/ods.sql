pause Run oradebug short_stack? (ENTER to continue, CTRL+C to cancel):
oradebug short_stack
