prompt Show instance memory usage breakdown from v$sga_dynamic_components
select * from v$sga_dynamic_components;
