@@ed &trc
