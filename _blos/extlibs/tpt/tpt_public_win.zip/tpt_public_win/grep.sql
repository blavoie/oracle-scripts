host egrep -i -e &1 -e "^\*" &trcfile

