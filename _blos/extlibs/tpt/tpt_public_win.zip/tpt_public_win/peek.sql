--prompt ---> oradebug peek 0x&1 64
oradebug peek 0x&1 64