set echo on
