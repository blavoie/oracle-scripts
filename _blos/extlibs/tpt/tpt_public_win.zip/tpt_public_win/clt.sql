oradebug setmypid
oradebug close_trace
