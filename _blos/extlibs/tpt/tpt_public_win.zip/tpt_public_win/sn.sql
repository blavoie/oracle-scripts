prompt @snapper all &1 1 "&2"
@@snapper all "&1" 1 "&2"
