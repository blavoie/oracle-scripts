prompt SQL> set serverout off
set serverout off

